from logger import Logger
from unidecode import unidecode

import re

class Preprocess(Logger):

    def __init__(self, l1_sentences, l2_sentences, verbose=False):

        super().__init__(verbose)

        assert len(l1_sentences) == len(l2_sentences)

        self.l1_sentences = l1_sentences
        self.l2_sentences = l2_sentences

    def remove_symbols(self, l1_symbols, l2_symbols, replaceable_symbols):

        for idx in range(len(self.l1_sentences)):
            
            re_str_l1 = r"[%s]" % re.escape("".join(l1_symbols))
            re_str_l2 = r"[%s]" % re.escape("".join(l2_symbols))

            self.l1_sentences[idx] = re.sub(re_str_l1, "", self.l1_sentences[idx])
            self.l2_sentences[idx] = re.sub(re_str_l2, "", self.l2_sentences[idx])

            for rep in replaceable_symbols:
                self.l1_sentences[idx] = ' '.join(self.l1_sentences[idx].replace(rep, replaceable_symbols[rep]).split())
                self.l2_sentences[idx] = ' '.join(self.l2_sentences[idx].replace(rep, replaceable_symbols[rep]).split())

    def unidecode_english(self, sentences):

        for idx in range(len(sentences)):
            sentences[idx] = unidecode(sentences[idx]) # remove accents from english sentences
            # Refer FAQs here: https://pypi.org/project/Unidecode/
            sentences[idx] = sentences[idx].replace("a<<", "e") # umlaut letter
            sentences[idx] = sentences[idx].replace("a 1/4", "u") # u with diaeresis
            sentences[idx] = sentences[idx].replace("a3", "o") # ó: a3 --> o
            
            sentences[idx] = sentences[idx].replace("a(r)", "i") # î: a(r) --> i
            sentences[idx] = sentences[idx].replace("a-", "i") # ï: a- --> i [dataset seems to also use ocr: ïடக்கக்கூடியதுதான்  --> i(da)kka for padi[kka]]
            sentences[idx] = sentences[idx].replace("a$?", "a") # ä: a$? --> a
            sentences[idx] = sentences[idx].replace("a'", "o") # ô: a' --> o
            sentences[idx] = sentences[idx].replace("d1", "e") # econostrum - single token
            sentences[idx] = sentences[idx].replace("a+-", "n") # ñ: a+- --> n
            sentences[idx] = sentences[idx].replace("a1", "u") # ù: a1 --> u
        
            # manual change
            num_and_a_half = lambda x: "%s%s" % (self.reserved_tokens[self.NUM_IDX], x) # NUM a half --> NUM and a half
            sentences[idx] = sentences[idx].replace(num_and_a_half(" a 1/2"), num_and_a_half(" and a half"))
        
        return sentences

