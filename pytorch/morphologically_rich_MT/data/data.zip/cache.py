import os
from logger import Logger

class Cache(Logger):

    def __init__(self, cache_dir, verbose=False):
        
        super().__init__(verbose)
        self.cache_dir = cache_dir

    def cache_file(self, fname, str_data, append=False):

        mode = "w" if not append else "a"

        with open(os.path.join(self.cache_dir, fname), mode) as f:
            f.write(str_data)

    def file_to_variable(self, fname):
        raise NotImplementedError

    def variable_to_file(self, variable):
        raise NotImplementedError
