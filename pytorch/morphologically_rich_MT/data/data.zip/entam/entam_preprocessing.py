from preprocess import Preprocess

class EnTamPreprocess(Preprocess):

    def __init__(self, l1_sentences, l2_sentences, symbols, removable_symbols, replaceable_symbols, verbose=False):
        # symbols: Boolean for all special characters
        # remove_symbols: removable list of symbols not in string.punctuation
        # replace_symbols: symbol replacements across unicode code blocks

        super().__init__(l1_sentences, l2_sentences, replaceable_symbols, verbose=verbose)
        
        self.symbols = symbols
        self.removable_symbols = removable_symbols
        self.replaceable_symbols = replaceable_symbols

        if not symbols:
            self.remove_symbols(string.punctuation + removable_symbols, string.punctuation + removable_symbols)

    def 
text_pairs = []
        translator = str.maketrans('', '', string.punctuation)
        
        unnecessary_symbols = ["‘", "¦", "¡", "¬", '“', '”', "’", '\u200c'] # negation symbol might not be in EnTamV2
        # Exclamation mark between words in train set
        
        if symbols:
            symbol_replacements = {unnecessary_symbols[0]: "'", unnecessary_symbols[4]: '"', unnecessary_symbols[5]: "\"", unnecessary_symbols[6]: "'"}
        else:
            symbol_replacements = {}
        
        if not dataset is None:
            eng_sentences = dataset[0]
 
