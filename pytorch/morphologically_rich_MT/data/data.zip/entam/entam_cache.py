from cache import Cache

entam_cache = Cache("entam_cache")

class EnTamCache(Cache):

    def __init__(self, cache_dir):

        super().__init__(cache_dir)
        
        if not os.path.isdir(cache_dir):
            os.makedirs(cache_dir)

    def cache_sentences(self, sentences, fname_suffix, lang=0):

        assert lang in [0,1]

        with open(os.path.join(self.cache_dir, "entam.%d." % lang + fname_suffix), 'w') as f:
            for idx, sentence in enumerate(sentences):
                if idx == len(sentences)-1:
                    f.write(sentence)
                else:
                    f.write(sentence + "\n")

    

